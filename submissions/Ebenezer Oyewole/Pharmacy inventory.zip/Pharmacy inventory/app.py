"""PharmaStock - Pharmacy Inventory System (Flask + SQLite)."""
import os, re, secrets, sqlite3
from datetime import date, datetime, timedelta
from functools import wraps
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash, abort, current_app)
from werkzeug.security import generate_password_hash, check_password_hash

LOW = 10                      # low-stock threshold
MAX_FAILS, LOCK_MIN = 5, 5    # brute-force lockout
CATEGORIES = ["Antibiotic", "Analgesic", "Antimalarial", "Antihypertensive",
              "Antidiabetic", "Vitamin", "Other"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
  failed INTEGER NOT NULL DEFAULT 0, locked_until TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS medicines(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, category TEXT NOT NULL, batch_no TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity>=0),
  unit_price REAL NOT NULL CHECK(unit_price>=0),
  expiry_date TEXT NOT NULL, supplier TEXT,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL);
"""

# ---------- input validation (whitelist patterns) ----------
USER_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+$")
FULL_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,59}$")
TEXT_RE = re.compile(r"^[\w\s.,()/%+-]{2,100}$")
BATCH_RE = re.compile(r"^[A-Za-z0-9-]{2,30}$")


def pw_errors(p):
    e = []
    if len(p) < 8 or len(p) > 128: e.append("Password must be 8-128 characters.")
    if not re.search(r"[A-Za-z]", p) or not re.search(r"\d", p):
        e.append("Password must contain at least one letter and one number.")
    return e


def validate_user(f, with_password=False):
    d = {"username": f.get("username", "").strip(), "email": f.get("email", "").strip().lower(),
         "full_name": f.get("full_name", "").strip()}
    e = []
    if with_password and not USER_RE.match(d["username"]):
        e.append("Username: 3-30 letters, numbers or underscores.")
    if not EMAIL_RE.match(d["email"]) or len(d["email"]) > 120: e.append("Enter a valid email address.")
    if not FULL_RE.match(d["full_name"]): e.append("Enter your full name (letters only).")
    if with_password:
        e += pw_errors(f.get("password", ""))
        if f.get("password") != f.get("confirm"): e.append("Passwords do not match.")
    return d, e


def validate_medicine(f):
    d, e = {}, []
    d["name"] = f.get("name", "").strip()
    if not TEXT_RE.match(d["name"]): e.append("Name: 2-100 characters; letters, numbers and . , ( ) / % + - only.")
    d["category"] = f.get("category", "")
    if d["category"] not in CATEGORIES: e.append("Choose a valid category.")
    d["batch_no"] = f.get("batch_no", "").strip()
    if not BATCH_RE.match(d["batch_no"]): e.append("Batch number: 2-30 letters, numbers or hyphens.")
    d["supplier"] = f.get("supplier", "").strip()
    if d["supplier"] and not TEXT_RE.match(d["supplier"]): e.append("Supplier contains invalid characters.")
    try:
        d["quantity"] = int(f.get("quantity", ""))
        if not 0 <= d["quantity"] <= 100000: raise ValueError
    except ValueError:
        e.append("Quantity must be a whole number from 0 to 100000.")
    try:
        d["unit_price"] = round(float(f.get("unit_price", "")), 2)
        if not 0 <= d["unit_price"] <= 1000000: raise ValueError
    except ValueError:
        e.append("Unit price must be a number from 0 to 1000000.")
    try:
        d["expiry_date"] = date.fromisoformat(f.get("expiry_date", "")).isoformat()
    except ValueError:
        e.append("Expiry date must be a valid date.")
    return d, e


# ---------- database ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def login_required(fn):
    @wraps(fn)
    def w(*a, **k):
        if not g.user:
            flash("Please log in to continue.", "err")
            return redirect(url_for("login"))
        return fn(*a, **k)
    return w


def role_required(*roles):  # access-control check on the server, not just hidden buttons
    def deco(fn):
        @wraps(fn)
        @login_required
        def w(*a, **k):
            if g.user["role"] not in roles: abort(403)
            return fn(*a, **k)
        return w
    return deco


def create_app(db_path=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        DATABASE=db_path or os.path.join(app.root_path, "pharmacy.db"),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("HTTPS") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
        MAX_CONTENT_LENGTH=100 * 1024)

    with app.app_context():
        db = get_db(); db.executescript(SCHEMA)
        if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
            pw = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(10)
            db.execute("INSERT INTO users(username,email,full_name,password_hash,role) VALUES(?,?,?,?,?)",
                       ("admin", "admin@pharmacy.local", "System Admin", generate_password_hash(pw), "admin"))
            db.commit()
            if not os.environ.get("ADMIN_PASSWORD"):
                print(f"\n[setup] Admin created -> username: admin  password: {pw}\n")
        db.close(); g.pop("db", None)

    @app.teardown_appcontext
    def close_db(_):
        db = g.pop("db", None)
        if db: db.close()

    @app.before_request
    def before():
        g.user = None
        uid = session.get("uid")
        if uid:
            g.user = get_db().execute("SELECT id,username,email,full_name,role FROM users WHERE id=?",
                                      (uid,)).fetchone()
            if not g.user: session.clear()
        if request.method == "POST":  # CSRF protection
            sent, tok = request.form.get("csrf", "").encode(), session.get("csrf", "").encode()
            if not tok or not secrets.compare_digest(sent, tok): abort(400)

    @app.after_request
    def headers(r):
        r.headers["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'none'; form-action 'self'"
        r.headers["X-Content-Type-Options"] = "nosniff"
        r.headers["X-Frame-Options"] = "DENY"
        r.headers["Referrer-Policy"] = "same-origin"
        if g.get("user"): r.headers["Cache-Control"] = "no-store"
        if app.config["SESSION_COOKIE_SECURE"]:
            r.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return r

    def csrf_token():
        if "csrf" not in session: session["csrf"] = secrets.token_hex(16)
        return session["csrf"]
    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.context_processor
    def ctx():
        t = date.today()
        return dict(today=t.isoformat(), soon=(t + timedelta(days=30)).isoformat(), low=LOW)

    # ---------- auth ----------
    @app.route("/register", methods=["GET", "POST"])
    def register():
        if g.user: return redirect(url_for("dashboard"))
        if request.method == "POST":
            d, errs = validate_user(request.form, True)
            if not errs:
                try:  # role is NEVER taken from the form: new accounts are always 'user'
                    get_db().execute("INSERT INTO users(username,email,full_name,password_hash) VALUES(?,?,?,?)",
                                     (d["username"], d["email"], d["full_name"],
                                      generate_password_hash(request.form["password"])))
                    get_db().commit()
                    flash("Account created. You can log in now.", "ok")
                    return redirect(url_for("login"))
                except sqlite3.IntegrityError:
                    errs.append("That username or email is already registered.")
            for e in errs: flash(e, "err")
            return render_template("register.html", f=request.form), 400
        return render_template("register.html", f={})

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user: return redirect(url_for("dashboard"))
        if request.method == "POST":
            db = get_db(); now = datetime.utcnow().isoformat()
            u = db.execute("SELECT * FROM users WHERE username=?", (request.form.get("username", "").strip(),)).fetchone()
            if u and u["locked_until"] and u["locked_until"] > now:
                flash("Account temporarily locked. Try again in a few minutes.", "err")
            elif u and check_password_hash(u["password_hash"], request.form.get("password", "")):
                db.execute("UPDATE users SET failed=0, locked_until=NULL WHERE id=?", (u["id"],)); db.commit()
                session.clear()                      # prevents session fixation
                session["uid"] = u["id"]; session.permanent = True
                return redirect(url_for("dashboard"))
            else:
                if u:
                    n = u["failed"] + 1
                    lock = (datetime.utcnow() + timedelta(minutes=LOCK_MIN)).isoformat() if n >= MAX_FAILS else None
                    db.execute("UPDATE users SET failed=?, locked_until=? WHERE id=?", (0 if lock else n, lock, u["id"]))
                    db.commit()
                flash("Invalid username or password.", "err")  # generic: doesn't reveal which was wrong
            return render_template("login.html"), 401
        return render_template("login.html")

    @app.route("/logout", methods=["POST"])
    def logout():
        session.clear(); flash("You have been logged out.", "ok")
        return redirect(url_for("login"))

    # ---------- dashboard & profile ----------
    @app.route("/")
    @login_required
    def dashboard():
        t = date.today().isoformat(); s30 = (date.today() + timedelta(days=30)).isoformat()
        db = get_db()
        s = db.execute("""SELECT COUNT(*) n, COALESCE(SUM(quantity*unit_price),0) v,
            COALESCE(SUM(quantity<=?),0) lowc, COALESCE(SUM(expiry_date<?),0) expc,
            COALESCE(SUM(expiry_date>=? AND expiry_date<=?),0) soonc FROM medicines""", (LOW, t, t, s30)).fetchone()
        alerts = db.execute("SELECT * FROM medicines WHERE quantity<=? OR expiry_date<=? ORDER BY expiry_date LIMIT 8",
                            (LOW, s30)).fetchall()
        return render_template("dashboard.html", s=s, alerts=alerts)

    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        db = get_db()
        if request.method == "POST":
            if request.form.get("action") == "password":
                row = db.execute("SELECT password_hash FROM users WHERE id=?", (g.user["id"],)).fetchone()
                new = request.form.get("new", ""); errs = pw_errors(new)
                if not check_password_hash(row["password_hash"], request.form.get("current", "")):
                    errs.append("Current password is incorrect.")
                if errs:
                    for e in errs: flash(e, "err")
                    return render_template("profile.html"), 400
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), g.user["id"]))
                db.commit(); session.clear()
                flash("Password changed. Please log in again.", "ok")
                return redirect(url_for("login"))
            d, errs = validate_user(request.form)
            if not errs:
                try:
                    db.execute("UPDATE users SET full_name=?, email=? WHERE id=?", (d["full_name"], d["email"], g.user["id"]))
                    db.commit(); flash("Profile updated.", "ok")
                    return redirect(url_for("profile"))
                except sqlite3.IntegrityError:
                    errs.append("That email is already in use.")
            for e in errs: flash(e, "err")
            return render_template("profile.html"), 400
        return render_template("profile.html")

    # ---------- medicines ----------
    @app.route("/medicines")
    @login_required
    def medicines():
        q = request.args.get("q", "").strip()[:50]
        cat, status = request.args.get("category", ""), request.args.get("status", "")
        sql, args = "SELECT * FROM medicines WHERE 1=1", []
        if q:   # parameterised query: user input is never concatenated into SQL
            sql += " AND (name LIKE ? OR batch_no LIKE ? OR supplier LIKE ?)"; args += [f"%{q}%"] * 3
        if cat in CATEGORIES: sql += " AND category=?"; args.append(cat)
        today = date.today().isoformat(); s30 = (date.today() + timedelta(days=30)).isoformat()
        if status == "low": sql += " AND quantity<=?"; args.append(LOW)
        elif status == "expired": sql += " AND expiry_date<?"; args.append(today)
        elif status == "soon": sql += " AND expiry_date>=? AND expiry_date<=?"; args += [today, s30]
        rows = get_db().execute(sql + " ORDER BY name LIMIT 500", args).fetchall()
        return render_template("medicines.html", rows=rows, q=q, cat=cat, status=status, cats=CATEGORIES)

    def medicine_form(mid=None):
        db = get_db(); m = None
        if mid:
            m = db.execute("SELECT * FROM medicines WHERE id=?", (mid,)).fetchone() or abort(404)
        if request.method == "POST":
            d, errs = validate_medicine(request.form)
            if errs:
                for e in errs: flash(e, "err")
                return render_template("medicine_form.html", m=request.form, mid=mid, cats=CATEGORIES), 400
            v = (d["name"], d["category"], d["batch_no"], d["quantity"], d["unit_price"],
                 d["expiry_date"], d["supplier"], g.user["id"])
            if mid:
                db.execute("UPDATE medicines SET name=?,category=?,batch_no=?,quantity=?,unit_price=?,"
                           "expiry_date=?,supplier=?,updated_by=? WHERE id=?", v + (mid,))
            else:
                db.execute("INSERT INTO medicines(name,category,batch_no,quantity,unit_price,expiry_date,"
                           "supplier,updated_by) VALUES(?,?,?,?,?,?,?,?)", v)
            db.commit(); flash("Medicine saved.", "ok")
            return redirect(url_for("medicines"))
        return render_template("medicine_form.html", m=m or {}, mid=mid, cats=CATEGORIES)

    @app.route("/medicines/new", methods=["GET", "POST"])
    @login_required
    def new_medicine(): return medicine_form()

    @app.route("/medicines/<int:mid>/edit", methods=["GET", "POST"])
    @login_required
    def edit_medicine(mid): return medicine_form(mid)

    @app.route("/medicines/<int:mid>/delete", methods=["POST"])
    @role_required("admin")
    def delete_medicine(mid):
        get_db().execute("DELETE FROM medicines WHERE id=?", (mid,)); get_db().commit()
        flash("Medicine deleted.", "ok")
        return redirect(url_for("medicines"))

    # ---------- admin ----------
    @app.route("/admin/users")
    @role_required("admin")
    def users():
        return render_template("users.html", rows=get_db().execute("SELECT * FROM users ORDER BY id").fetchall())

    @app.route("/admin/users/<int:uid>/role", methods=["POST"])
    @role_required("admin")
    def set_role(uid):
        role = request.form.get("role")
        if role not in ("admin", "user") or uid == g.user["id"]: abort(400)
        get_db().execute("UPDATE users SET role=? WHERE id=?", (role, uid)); get_db().commit()
        flash("Role updated.", "ok"); return redirect(url_for("users"))

    @app.route("/admin/users/<int:uid>/delete", methods=["POST"])
    @role_required("admin")
    def delete_user(uid):
        if uid == g.user["id"]: abort(400)
        get_db().execute("DELETE FROM users WHERE id=?", (uid,)); get_db().commit()
        flash("User deleted.", "ok"); return redirect(url_for("users"))

    @app.route("/security")
    def security(): return render_template("security.html")

    # ---------- error handling (no stack traces shown to users) ----------
    MSG = {400: "The request was invalid or your form expired. Go back and try again.",
           403: "You don't have permission to view this page.",
           404: "We couldn't find that page.", 405: "That action isn't allowed here.",
           413: "The request was too large.", 500: "Something went wrong on our side."}
    for code, text in MSG.items():
        app.register_error_handler(code, lambda e, c=code, t=text: (render_template("error.html", code=c, msg=t), c))
    return app


if __name__ == "__main__":
    create_app().run(ssl_context="adhoc" if os.environ.get("HTTPS") == "1" else None)
