# PharmaStock - Pharmacy Inventory System (Flask + SQLite)

## Run
    python -m venv venv
    source venv/bin/activate          # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    python app.py                     # open http://127.0.0.1:5000

First start creates `pharmacy.db` and prints the admin password once (username `admin`).
To choose it yourself: `ADMIN_PASSWORD='YourPass123' python app.py`
(Windows PowerShell: `$env:ADMIN_PASSWORD='YourPass123'; python app.py`).
Set `SECRET_KEY` to keep sessions valid across restarts. Set `HTTPS=1` (and `pip install cryptography`) for local HTTPS.

## Automated tests
    pytest -v

## Manual test checklist (record Pass/Fail and screenshots in your report)
| Area | What to try | Expected |
|---|---|---|
| Registration | Empty fields, bad email, weak password, duplicate username | Clear error, no account |
| Login | Wrong password x5, then correct password | Generic error, then lockout message |
| Forms | Quantity -1 / "abc", past or invalid dates, `<script>` in name | Rejected with message |
| Roles | Log in as a normal user, open /admin/users | 403 page; no Users link, no Delete buttons |
| SQL injection | Search for `' OR 1=1 --` | Normal results, no error |
| XSS | Search for `<script>alert(1)</script>` | Shown as text, no popup |
| Session | Log out, press Back, then reload | Redirected to login |
| Usability | Ask a classmate to add a medicine and find it | Done without help; note issues |
| Responsive | Browser dev tools: 375px phone, 768px tablet, desktop | Menu collapses, tables become stacked rows |
| Errors | Visit /nope | Friendly 404, no stack trace |
