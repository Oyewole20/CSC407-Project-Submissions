import os, re, sqlite3, sys
import pytest
os.environ["ADMIN_PASSWORD"] = "Admin#12345"
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app

GOOD = dict(name="Amoxicillin 500mg", category="Antibiotic", batch_no="AMX-01", quantity="50",
            unit_price="12.50", expiry_date="2030-01-31", supplier="MediSupply")


@pytest.fixture
def env(tmp_path):
    path = str(tmp_path / "t.db")
    app = create_app(path); app.config["TESTING"] = True
    return app.test_client(), path


def tok(c):
    return re.search(r'<meta name="csrf" content="([^"]+)">', c.get("/security").get_data(as_text=True)).group(1)


def post(c, url, data, follow=True):
    return c.post(url, data={**data, "csrf": tok(c)}, follow_redirects=follow)


def register(c, u="alice", pw="Passw0rd1"):
    return post(c, "/register", dict(full_name="Alice Doe", username=u, email=f"{u}@x.com", password=pw, confirm=pw))


def login(c, u="alice", pw="Passw0rd1"):
    return post(c, "/login", dict(username=u, password=pw))


# ---- functional / login / registration ----
def test_register_login_logout(env):
    c, _ = env
    assert b"Account created" in register(c).data
    assert b"Hello, Alice Doe" in login(c).data
    assert b"logged out" in post(c, "/logout", {}).data
    assert c.get("/", follow_redirects=False).status_code == 302

def test_duplicate_username_rejected(env):
    c, _ = env; register(c)
    assert b"already registered" in register(c).data

def test_wrong_password_generic_message(env):
    c, _ = env; register(c)
    r = login(c, pw="Wrong1234")
    assert b"Invalid username or password" in r.data

# ---- form validation ----
@pytest.mark.parametrize("pw", ["short1", "allletters", "12345678"])
def test_weak_passwords_rejected(env, pw):
    c, _ = env
    assert b"Password" in register(c, pw=pw).data

def test_invalid_medicine_values(env):
    c, _ = env; register(c); login(c)
    for bad in [dict(quantity="-5"), dict(quantity="abc"), dict(unit_price="x"),
                dict(expiry_date="2030-13-45"), dict(category="Hacked"), dict(name="<script>alert(1)</script>")]:
        assert post(c, "/medicines/new", {**GOOD, **bad}, follow=False).status_code == 400

# ---- database ----
def test_password_stored_hashed(env):
    c, path = env; register(c)
    h = sqlite3.connect(path).execute("SELECT password_hash FROM users WHERE username='alice'").fetchone()[0]
    assert "Passw0rd1" not in h and h.startswith(("scrypt:", "pbkdf2:"))

def test_medicine_crud_and_search(env):
    c, path = env; login(c, "admin", "Admin#12345")
    assert b"Medicine saved" in post(c, "/medicines/new", GOOD).data
    post(c, "/medicines/new", {**GOOD, "name": "Paracetamol", "category": "Analgesic", "quantity": "3", "batch_no": "PCM-9"})
    assert b"Amoxicillin" in c.get("/medicines?q=amox").data and b"Paracetamol" not in c.get("/medicines?q=amox").data
    assert b"Paracetamol" in c.get("/medicines?status=low").data
    assert sqlite3.connect(path).execute("SELECT COUNT(*) FROM medicines").fetchone()[0] == 2
    assert b"Medicine deleted" in post(c, "/medicines/1/delete", {}).data

# ---- security ----
def test_login_required(env):
    c, _ = env
    for url in ["/", "/medicines", "/profile", "/medicines/new", "/admin/users"]:
        assert c.get(url).status_code == 302

def test_user_cannot_reach_admin_or_delete(env):
    c, _ = env; register(c); login(c)
    assert c.get("/admin/users").status_code == 403
    assert post(c, "/medicines/1/delete", {}, follow=False).status_code == 403

def test_cannot_self_assign_admin_on_register(env):
    c, path = env
    post(c, "/register", dict(full_name="Eve Doe", username="eve", email="e@x.com", password="Passw0rd1",
                              confirm="Passw0rd1", role="admin"))
    assert sqlite3.connect(path).execute("SELECT role FROM users WHERE username='eve'").fetchone()[0] == "user"

def test_sql_injection_login_and_search(env):
    c, _ = env; register(c)
    assert b"Invalid username" in post(c, "/login", dict(username="admin' OR '1'='1' --", password="x")).data
    login(c)
    assert c.get("/medicines?q=' OR 1=1 --").status_code == 200
    assert c.get("/medicines?q='; DROP TABLE medicines; --").status_code == 200
    assert c.get("/medicines").status_code == 200

def test_xss_is_escaped(env):
    c, _ = env; register(c); login(c)
    body = c.get("/medicines?q=<script>alert(1)</script>").get_data(as_text=True)
    assert "<script>alert(1)</script>" not in body and "&lt;script&gt;" in body

def test_csrf_blocks_missing_token(env):
    c, _ = env
    assert c.post("/login", data=dict(username="admin", password="Admin#12345")).status_code == 400

def test_account_lockout(env):
    c, _ = env; register(c)
    for _ in range(5): login(c, pw="Wrong1234")
    assert b"locked" in login(c).data

def test_security_headers_and_cookie_flags(env):
    c, _ = env; r = c.get("/security")
    assert "Content-Security-Policy" in r.headers and r.headers["X-Frame-Options"] == "DENY"
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert "HttpOnly" in post(c, "/login", dict(username="admin", password="Admin#12345"), follow=False).headers["Set-Cookie"]

# ---- error handling ----
def test_custom_404_has_no_stack_trace(env):
    c, _ = env; r = c.get("/nope")
    assert r.status_code == 404 and b"couldn't find" in r.data and b"Traceback" not in r.data
